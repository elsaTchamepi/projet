--insert into contacts(nom,prenom) VALUES('tchamepi','elsa' );
 --SELECT * FROM contacts;
 